NOTATKI+ – wersja ze wspólną bazą (Netlify)

1) Wrzuć ten folder na GitHub (nowe repozytorium, przeciągnij pliki).
2) Netlify → Add new site → Import from Git → wybierz repozytorium.
   (Ustawienia buildu uzupełnią się same z netlify.toml.)
3) Netlify → Site configuration → Environment variables → dodaj:
      ADMIN_PASSWORD = twoje_hasło
   i zrób Deploys → Trigger deploy.
4) Wejdź na stronę, kliknij kłódkę i zaloguj się swoim hasłem.

Alternatywa bez GitHuba: zainstaluj Netlify CLI i w tym folderze uruchom:
   npm i -g netlify-cli
   netlify deploy --prod
(zwykłe przeciągnięcie folderu do Netlify Drop może nie zainstalować zależności funkcji).
